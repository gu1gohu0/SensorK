package com.example.trabsensor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.Bundle
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import android.view.Menu
import android.view.MenuItem
import com.example.trabsensor.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        val navController = findNavController(R.id.nav_host_fragment_content_main)
        appBarConfiguration = AppBarConfiguration(navController.graph)
        setupActionBarWithNavController(navController, appBarConfiguration)

        val sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager

        val device: List<Sensor> = sensorManager.getSensorList(Sensor.TYPE_ACCELEROMETER)
        val device2: List<Sensor> = sensorManager.getSensorList(Sensor.TYPE_AMBIENT_TEMPERATURE)
        val device3: List<Sensor> = sensorManager.getSensorList(Sensor.TYPE_GRAVITY)
        val device4: List<Sensor> = sensorManager.getSensorList(Sensor.TYPE_GYROSCOPE)
        val device5: List<Sensor> = sensorManager.getSensorList(Sensor.TYPE_LIGHT)

        device.toString()
        device2.toString()
        device3.toString()
        device4.toString()
        device5.toString()

        binding.sensor1.setOnClickListener { view ->
            Snackbar.make(view, device.toString(),Snackbar.LENGTH_LONG)
                .setAction("Action",null).show()
        }

        binding.sensor2.setOnClickListener { view ->
            Snackbar.make(view,device2.toString(),Snackbar.LENGTH_LONG)
                .setAction("Action2",null).show()
        }

        binding.sensor3.setOnClickListener { view ->
            Snackbar.make(view,device3.toString(),Snackbar.LENGTH_LONG)
                .setAction("Action3",null).show()
        }

        binding.sensor4.setOnClickListener { view ->
            Snackbar.make(view,device4.toString(),Snackbar.LENGTH_LONG)
                .setAction("Action4",null).show()
        }

        binding.sensor5.setOnClickListener { view ->
            Snackbar.make(view,device5.toString(),Snackbar.LENGTH_LONG)
                .setAction("Action5",null).show()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration)
                || super.onSupportNavigateUp()
    }
}